def read_file_content(file_name):

    with open("./story.txt", 'r') as file:
        file = file.read()
        return file


def count_words():
    text_document = read_file_content("./story.txt").strip()
    words = text_document.split()
    count = {}
    for word in words:
        if word in count:
            count[word] += 1
        else:
            count[word] = 1

    return count


print(count_words())
